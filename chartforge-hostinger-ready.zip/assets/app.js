const symbols=[
  ["BTCUSDT","Bitcoin / TetherUS","68,432.21","+2.34%","₿"],
  ["ETHUSDT","Ethereum / TetherUS","3,247.56","+1.82%","Ξ"],
  ["XAUUSD","Gold / US Dollar","2,658.42","+0.67%","●"],
  ["USOIL","Crude Oil WTI","73.21","+0.45%","●"],
  ["EURUSD","Euro / US Dollar","1.1124","-0.12%","€"],
  ["GBPUSD","British Pound / US Dollar","1.3257","-0.08%","£"],
  ["AAPL","Apple Inc.","229.18","+0.76%","●"],
  ["TSLA","Tesla Inc.","248.42","+1.34%","T"],
  ["NIFTY","Nifty 50","24,783.60","+0.58%","🇮🇳"],
  ["BANKNIFTY","Nifty Bank","51,236.45","+0.72%","🇮🇳"]
];
let selectedIndicators=["SMA","EMA"], chart, candleSeries, emaSeries, smaSeries, bars=[];

function renderWatch(){
  const el=document.getElementById("watchItems");
  el.innerHTML=symbols.map(s=>`<button class="watch-item" style="width:100%;border:0;background:transparent;color:inherit;text-align:left" onclick="selectSymbol('${s[0]}')">
    <span class="coin">${s[4]}</span><span><b>${s[0]}</b><small>${s[1]}</small></span>
    <span class="quote">${s[2]}<i>${s[3]}</i></span></button>`).join("");
}
function makeBars(n=160,base=62000){
  let p=base; const out=[]; const now=Math.floor(Date.now()/1000)-n*3600;
  for(let i=0;i<n;i++){const drift=(Math.random()-.43)*700;p+=drift;const o=p,c=p+(Math.random()-.42)*550,h=Math.max(o,c)+Math.random()*260,l=Math.min(o,c)-Math.random()*260;out.push({time:now+i*3600,open:o,high:h,low:l,close:c});}
  return out;
}
function sma(data,len){return data.map((_,i)=>i<len-1?null:data.slice(i-len+1,i+1).reduce((a,b)=>a+b.close,0)/len)}
function ema(data,len){let prev=null;return data.map((b,i)=>{if(i===len-1)prev=data.slice(0,len).reduce((a,x)=>a+x.close,0)/len;else if(i>=len)prev=b.close*(2/(len+1))+prev*(1-2/(len+1));return i>=len-1?prev:null})}
function draw(){
  if(!window.LightweightCharts)return;
  const el=document.getElementById("chart");
  chart=LightweightCharts.createChart(el,{layout:{background:{color:"#06101c"},textColor:"#71869f"},grid:{vertLines:{color:"#102238"},horzLines:{color:"#102238"}},rightPriceScale:{borderColor:"#16314e"},timeScale:{borderColor:"#16314e"},crosshair:{mode:1}});
  candleSeries=chart.addSeries(LightweightCharts.CandlestickSeries,{upColor:"#00cba2",downColor:"#ff5365",borderVisible:false,wickUpColor:"#00cba2",wickDownColor:"#ff5365"});
  smaSeries=chart.addSeries(LightweightCharts.LineSeries,{color:"#24a7ff",lineWidth:2});
  emaSeries=chart.addSeries(LightweightCharts.LineSeries,{color:"#f4a72c",lineWidth:2});
  bars=makeBars(); updateChart(); new ResizeObserver(()=>chart.applyOptions({width:el.clientWidth,height:el.clientHeight})).observe(el);
}
function updateChart(){candleSeries.setData(bars);smaSeries.setData(bars.map((b,i)=>({time:b.time,value:sma(bars,20)[i]})).filter(x=>x.value));emaSeries.setData(bars.map((b,i)=>({time:b.time,value:ema(bars,50)[i]})).filter(x=>x.value));chart.timeScale().fitContent();}
function selectSymbol(s){document.getElementById("symbolInput").value=s;loadSymbol()}
function loadSymbol(){const s=document.getElementById("symbolInput").value.toUpperCase();document.getElementById("assetSymbol").textContent=s;document.getElementById("chartName").textContent=s+" · 1h · DEMO";const match=symbols.find(x=>x[0]===s);if(match){document.getElementById("price").innerHTML=match[2]+' <small>USD</small>'}bars=makeBars(160,s==="BTCUSDT"?62000:s==="ETHUSDT"?3000:1000);updateChart()}
function toggleIndicator(name){if(!selectedIndicators.includes(name)&&selectedIndicators.length>=2){openUpgrade();return}selectedIndicators.includes(name)?selectedIndicators=selectedIndicators.filter(x=>x!==name):selectedIndicators.push(name);document.getElementById("indicatorCount").textContent=`(${selectedIndicators.length}/2 free)`}
function runBacktest(){const f=+document.getElementById("fast").value,s=+document.getElementById("slow").value;if(f>=s){alert("Fast period must be smaller than Slow period");return}const ret=(Math.random()*18-3).toFixed(2);document.getElementById("return").textContent=ret+"%";document.getElementById("win").textContent=(55+Math.random()*15).toFixed(1)+"%";document.getElementById("trades").textContent=Math.floor(25+Math.random()*55)}
function addSymbol(){const s=prompt("Enter symbol, e.g. BTCUSDT");if(!s)return;symbols.push([s.toUpperCase(),s.toUpperCase()+" · Custom","—","+0.00%","●"]);renderWatch()}
function openUpgrade(){document.getElementById("upgradeModal").style.display="grid"}
function closeUpgrade(){document.getElementById("upgradeModal").style.display="none"}
function startCheckout(){alert("Razorpay checkout placeholder. Connect your server-side Razorpay subscription API before accepting real payments.");closeUpgrade()}
function toggleDock(){const x=document.querySelector(".tool-grid");x.style.display=x.style.display==="none"?"grid":"none"}
function scrollToBacktest(){document.querySelector(".backtest-card").scrollIntoView({behavior:"smooth"})}
document.getElementById("themeBtn").onclick=()=>document.body.classList.toggle("light");
renderWatch();draw();
