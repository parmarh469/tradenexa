CHARTFORGE HOSTINGER INSTALLATION

This package is a build-free frontend. It can be uploaded directly to Hostinger shared hosting.

1) Login to Hostinger hPanel.
2) Open File Manager.
3) Open public_html.
4) Upload all contents of this folder:
   - index.html
   - assets/style.css
   - assets/app.js
5) Make sure index.html is directly inside public_html.
6) Open your domain.

The chart currently uses demo-generated OHLC data so the site works immediately without an API key.

IMPORTANT:
- This is the frontend prototype.
- The ₹299 button is only a placeholder until a secure server-side Razorpay integration is connected.
- Real market data should be obtained from a provider whose licence permits display/redistribution.
- Do not put private API keys or Razorpay secret keys inside assets/app.js or any browser file.
- If you want live Indian stock/MCX/NSE/BSE data, use a properly licensed data/broker API and a server-side proxy.
- If you want actual login/database/payment, Hostinger's server-side stack (PHP/Node support depending on plan) or an external backend can be connected.

For production:
Frontend -> HTTPS -> backend API -> market data provider
Frontend -> backend -> Razorpay
Frontend -> Supabase/MySQL/PostgreSQL
